/*
Xpress DNS: Experimental XDP DNS responder
Copyright (C) 2021 Bas Schalbroeck <schalbroeck@gmail.com>

SPDX-License-Identifier: GPL-2.0-or-later

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330
*/
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <bpf/bpf.h>
#include <errno.h>
//bpf_elf.h is part of iproute2
#include <iproute2/bpf_elf.h>
// #include "common.h"
#include <bpf/libbpf.h>

#define MAX_DNS_NAME_LENGTH 256
#define A_RECORD_TYPE 0x0001
#define DNS_CLASS_IN 0x0001

int get_map_fd();
void replace_dots_with_length_octets(char *dns_name, char *new_dns_name);
void replace_length_octets_with_dots(char *dns_name, char *new_dns_name);

int update_ebpf_map(int a_records_fd, char *dns_name, struct in_addr addr, int ttl);
int delete_ebpf_map(int a_records_fd, char *dns_name);

//Used as key in our hashmap
struct dns_query {
    uint16_t record_type;
    uint16_t class;
    char name[MAX_DNS_NAME_LENGTH];
};

struct a_record {
    struct in_addr ip_addr;
    uint32_t ttl;
};
