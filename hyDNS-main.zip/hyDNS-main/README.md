# hyDNS

Need to enable save-expired, change smartdns config, add these 


    serve-expired yes
    serve-expired-ttl 5

