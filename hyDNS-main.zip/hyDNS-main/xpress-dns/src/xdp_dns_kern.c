/*
Xpress DNS: Experimental XDP DNS responder
Copyright (C) 2021 Bas Schalbroeck <schalbroeck@gmail.com>

SPDX-License-Identifier: GPL-2.0-or-later

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330
*/
#define DEFAULT_ACTION XDP_PASS

#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/version.h>

//This program supports XDP in BCC and libbpf+iproute2 mode
//Include different files depending on mode
#ifndef BCC_SEC
#include <netinet/in.h>
#include <bpf_helpers.h>
#include <bpf_endian.h>
#include <string.h>
#include <stdint.h>
//bpf_elf.h is part of iproute2
#include <bpf_elf.h>
#endif

#include "common.h"

//Create different BPF maps depending on if we're using libbpf or BCC
// #ifdef BCC_SEC
// BPF_HASH(xdns_a_records, struct dns_query, struct a_record);
// #else
//Hash table for DNS A Records loaded by iproute2
//Key is a dns_query struct, value is the associated IPv4 address
struct bpf_elf_map SEC("maps") xdns_a_records = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(struct dns_query),
    .size_value = sizeof(struct a_record),
    .max_elem = 65536,
    .pinning = 2, //PIN_GLOBAL_NS
};

struct bpf_elf_map SEC("maps") xdp_tx_ports = {
    .type = BPF_MAP_TYPE_DEVMAP,
    .size_key = sizeof(int),
    .size_value = sizeof(int),
    .max_elem = 64,
};

struct bpf_elf_map SEC("maps") xdns_pending_list = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(struct pending_key),
    .size_value = sizeof(struct pending_request),
    .max_elem = 65536,
    .pinning = 2, //PIN_GLOBAL_NS
};

struct bpf_elf_map SEC("maps") xdns_pending_num = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(uint32_t),
    .size_value = sizeof(uint32_t),
    .max_elem = 1,
    .pinning = 2, //PIN_GLOBAL_NS
};

struct bpf_elf_map SEC("maps") xdns_hit = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(uint32_t),
    .size_value = sizeof(uint32_t),
    .max_elem = 1,
    .pinning = 2, //PIN_GLOBAL_NS
};

struct bpf_elf_map SEC("maps") xdns_miss = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(uint32_t),
    .size_value = sizeof(uint32_t),
    .max_elem = 1,
    .pinning = 2, //PIN_GLOBAL_NS
};


#define MAX_PENDING 256


// #endif

static int match_a_records(struct xdp_md *ctx, struct dns_query *q, struct a_record *a);
static int parse_query(struct xdp_md *ctx, void *query_start, struct dns_query *q);
// static int parse_resp(struct xdp_md *ctx, void *query_start, struct dns_rr *r);
static void create_query_response(struct a_record *a, char *dns_buffer, size_t *buf_size);
#ifdef EDNS
static inline int create_ar_response(struct ar_hdr *ar, char *dns_buffer, size_t *buf_size);
static inline int parse_ar(struct xdp_md *ctx, struct dns_hdr *dns_hdr, int query_length, struct ar_hdr *ar);
#endif
static inline void modify_dns_header_response(struct dns_hdr *dns_hdr);
static inline void update_ip_checksum(void *data, int len, uint16_t *checksum_location);
static inline void copy_to_pkt_buf(struct xdp_md *ctx, void *dst, void *src, size_t n);
static inline void swap_mac(uint8_t *src_mac, uint8_t *dst_mac);

char dns_buffer[512];

// #ifndef BCC_SEC
// SEC("prog")
// #endif
SEC("prog")
int xdp_dns(struct xdp_md *ctx)
{
    #ifdef DEBUG
    uint64_t start = bpf_ktime_get_ns();
    #endif
    #ifdef BCC_SEC
    char dns_buffer[512];
    #endif
   
    void *data_end = (void *)(unsigned long)ctx->data_end;
    void *data = (void *)(unsigned long)ctx->data;

    //Boundary check: check if packet is larger than a full ethernet + ip header
    if (data + sizeof(struct ethhdr) + sizeof(struct iphdr) > data_end)
    {
        return DEFAULT_ACTION;
    }

    struct ethhdr *eth = data;

    //Ignore packet if ethernet protocol is not IP-based
    if (eth->h_proto != bpf_htons(ETH_P_IP))
    {
        return DEFAULT_ACTION;
    }

    struct iphdr *ip = data + sizeof(*eth);

    if (ip->protocol == IPPROTO_UDP)
    {
        struct udphdr *udp;
        //Boundary check for UDP
        if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp) > data_end)
        {
            return DEFAULT_ACTION;
        }
        
        udp = data + sizeof(*eth) + sizeof(*ip);
        // not a DNS packet
        if (udp->dest != bpf_htons(53) && udp->source != bpf_htons(53)){
            return DEFAULT_ACTION;
        }

        uint64_t timestamp = bpf_ktime_get_ns() / 1000000000;
        //Boundary check for minimal DNS header
        if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp) + sizeof(struct dns_hdr) > data_end)
        {
            return DEFAULT_ACTION;
        }
        struct dns_hdr *dns_hdr = data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp);

        //Get a pointer to the start of the DNS query
        void *query_start = (void *)dns_hdr + sizeof(struct dns_hdr);
        
        struct dns_query q;
        int query_length = 0;
        query_length = parse_query(ctx, query_start, &q);
        if (query_length < 1)
        {
            return DEFAULT_ACTION;
        }

 
        //Check if dest port equals 53
        if (udp->dest == bpf_htons(53))
        {
            #ifdef DEBUG
            bpf_printk("------Received from client-------");
            bpf_printk("Packet dest port 53");
            bpf_printk("DNS name: %s", q.name);
            #endif

            //Check if header contains a standard query
            if (dns_hdr->qr != 0 || dns_hdr->opcode != 0)
            return DEFAULT_ACTION;
            
            #ifdef DEBUG
            bpf_printk("DNS query transaction id %u", bpf_ntohs(dns_hdr->transaction_id));
            #endif

            //Check if query matches a record in our hash table
            struct a_record a_record;
            int res = match_a_records(ctx, &q, &a_record);

            if(res == 0){

                #ifdef DEBUG

                bpf_printk("timestamp now : %lu", timestamp);
                bpf_printk("cache inserted: %lu", a_record.time_inserted_ns);
                bpf_printk("cache ttl: %d", a_record.ttl);
                #endif

                if(a_record.ttl <= timestamp - a_record.time_inserted_ns){
                    #ifdef DEBUG
                    bpf_printk("cache entry expired");
                    #endif
                    res = -1;
                }
                
            }
            //If query matches...
            if (res == 0)
            {   
                int cache_hit_key = 0;
                uint32_t* cache_hit_value = bpf_map_lookup_elem(&xdns_hit, &cache_hit_key);
                if(!cache_hit_value){
                    #ifdef DEBUG
                    bpf_printk("init cache_hit_value");
                    #endif
                    int value = 0;
                    bpf_map_update_elem(&xdns_hit, &cache_hit_key, &value, BPF_ANY);
                    cache_hit_value = bpf_map_lookup_elem(&xdns_hit, &cache_hit_key);
                    if(!cache_hit_value) return DEFAULT_ACTION;      
                }

                #ifdef DEBUG
                bpf_printk("cache_hit_value : %d", *cache_hit_value);
                #endif
                __sync_fetch_and_add(cache_hit_value, 1);

                size_t buf_size = 0;

                //Change DNS header to a valid response header
                modify_dns_header_response(dns_hdr);

                //Create DNS response and add to temporary buffer.
                create_query_response(&a_record, &dns_buffer[buf_size], &buf_size);

                #ifdef EDNS
                //If an additional record is present
                if(dns_hdr->add_count > 0)
                {
                    //Parse AR record
                    struct ar_hdr ar;
                    if(parse_ar(ctx, dns_hdr, query_length, &ar) != -1)
                    {     
                        //Create AR response and add to temporary buffer
                        create_ar_response(&ar, &dns_buffer[buf_size], &buf_size);
                    }
                }
                #endif

                //Start our response [query_length] bytes beyond the header
                void *answer_start = (void *)dns_hdr + sizeof(struct dns_hdr) + query_length;
                //Determine increment of packet buffer
                int tailadjust = answer_start + buf_size - data_end;

                //Adjust packet length accordingly
                if (bpf_xdp_adjust_tail(ctx, tailadjust))
                {
                    #ifdef DEBUG
                    bpf_printk("Adjust tail fail");
                    #endif
                }
                else
                {
                    //Because we adjusted packet length, mem addresses might be changed.
                    //Reinit pointers, as verifier will complain otherwise.
                    data = (void *)(unsigned long)ctx->data;
                    data_end = (void *)(unsigned long)ctx->data_end;

                    //Copy bytes from our temporary buffer to packet buffer
                    copy_to_pkt_buf(ctx, data + sizeof(struct ethhdr) +
                            sizeof(struct iphdr) +
                            sizeof(struct udphdr) +
                            sizeof(struct dns_hdr) +
                            query_length,
                        &dns_buffer[0], buf_size);

                    eth = data;
                    ip = data + sizeof(struct ethhdr);
                    udp = data + sizeof(struct ethhdr) + sizeof(struct iphdr);

                    //Do a new boundary check
                    if (data + sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) > data_end)
                    {
                        #ifdef DEBUG
                        bpf_printk("Error: Boundary exceeded");
                        #endif
                        return DEFAULT_ACTION;
                    }

                    //Adjust UDP length and IP length
                    uint16_t iplen = (data_end - data) - sizeof(struct ethhdr);
                    uint16_t udplen = (data_end - data) - sizeof(struct ethhdr) - sizeof(struct iphdr);
                    ip->tot_len = bpf_htons(iplen);
                    udp->len = bpf_htons(udplen);

                    //Swap eth macs
                    swap_mac((uint8_t *)eth->h_source, (uint8_t *)eth->h_dest);

                    //Swap src/dst IP
                    uint32_t src_ip = ip->saddr;
                    ip->saddr = ip->daddr;
                    ip->daddr = src_ip;

                    //Set UDP checksum to zero
                    udp->check = 0;

                    //Swap udp src/dst ports
                    uint16_t tmp_src = udp->source;
                    udp->source = udp->dest;
                    udp->dest = tmp_src;

                    //Recalculate IP checksum
                    update_ip_checksum(ip, sizeof(struct iphdr), &ip->check);

                    #ifdef DEBUG
                    bpf_printk("XDP_TX");
                    #endif

        
                    #ifdef DEBUG
                    uint64_t end = bpf_ktime_get_ns();
                    uint64_t elapsed = end-start;
                    bpf_printk("Time elapsed: %d", elapsed);
                    #endif

                    //Emit modified packet
                    return XDP_TX;
                }
            }
            else{
                // increase cache_miss counter
                int cache_miss_key = 0;
                uint32_t* cache_miss_value = bpf_map_lookup_elem(&xdns_miss, &cache_miss_key);
                if(!cache_miss_value){
                    #ifdef DEBUG
                    bpf_printk("init cache_hit_value");
                    #endif
                    int value = 0;
                    bpf_map_update_elem(&xdns_miss, &cache_miss_key, &value, BPF_ANY);
                    cache_miss_value = bpf_map_lookup_elem(&xdns_miss, &cache_miss_key);
                    if(!cache_miss_value) return DEFAULT_ACTION;      
                }

                #ifdef DEBUG
                bpf_printk("cache_miss_value : %d", *cache_miss_value);
                #endif
                __sync_fetch_and_add(cache_miss_value, 1);

                // count pending requests
                int pending_num_key = 0;
                uint32_t* pending_num_value = bpf_map_lookup_elem(&xdns_pending_num, &pending_num_key);
                if(!pending_num_value){
                    #ifdef DEBUG
                    bpf_printk("init xdns_pending_num");
                    #endif
                    int value = 0;
                    bpf_map_update_elem(&xdns_pending_num, &pending_num_key, &value, BPF_ANY);
                    pending_num_value = bpf_map_lookup_elem(&xdns_pending_num, &pending_num_key);
                }
                else if (*pending_num_value > MAX_PENDING)
                {
                    #ifdef DEBUG
                    bpf_printk("---too much pending requests, send to user space");
                    #endif
                    return DEFAULT_ACTION;
                }

                if(!pending_num_value){
                    return DEFAULT_ACTION;
                }
                #ifdef DEBUG
                bpf_printk("pending_num_value : %d", *pending_num_value);
                #endif
                __sync_fetch_and_add(pending_num_value, 1); 

                // add to pending list, modify the packet, send to upstream
                struct pending_key key;
                
                struct pending_request value;
                struct pending_request* test;

                // struct pending_request* value;
                key.transaction_id = dns_hdr -> transaction_id;
                key.source = udp->source;

                test = bpf_map_lookup_elem(&xdns_pending_list, &key);

                if (test > 0)
                {
                    #ifdef DEBUG
                    bpf_printk("Repeated");
                    #endif

                    return XDP_DROP;
                }
                
                value.saddr = ip->saddr;

                #ifdef DEBUG
                bpf_printk("ip->saddr: %lu", ip->saddr);
                bpf_printk("ip->daddr: %lu", ip->daddr);
                bpf_printk("udp->source: %d", udp->source);
                bpf_printk("udp->dest: %d", udp->dest);

                bpf_printk("key.transaction_id: %d", key.transaction_id);
                bpf_printk("key.source: %d", key.source);
                bpf_printk("value.saddr: %lu", value.saddr);
                bpf_printk("udp->dest: %d", udp->dest);
                #endif

                bpf_map_update_elem(&xdns_pending_list, &key, &value, BPF_ANY);

                struct bpf_fib_lookup fib_params;
                __builtin_memset(&fib_params, 0, sizeof(fib_params));

                fib_params.family	= AF_INET;
                fib_params.tos		= ip->tos;
                fib_params.l4_protocol	= ip->protocol;
                fib_params.sport	= 0;
                fib_params.dport	= 0;
                fib_params.tot_len	= ntohs(ip->tot_len);
                fib_params.ipv4_src	= ip->daddr;
                fib_params.ipv4_dst	= (0x08080808);

                fib_params.ifindex = ctx->ingress_ifindex;

                int rc = bpf_fib_lookup(ctx, &fib_params, sizeof(fib_params), BPF_FIB_LOOKUP_DIRECT);

                if (rc == BPF_FIB_LKUP_RET_SUCCESS) {

                    //Swap src/dst IP
                    ip->saddr = ip->daddr;
                    ip->daddr = (0x08080808);
    
                    //Recalculate IP checksum
                    update_ip_checksum(ip, sizeof(struct iphdr), &ip->check);
                    udp->check = 0;
                    memcpy(eth->h_dest, fib_params.dmac, ETH_ALEN);
                    memcpy(eth->h_source, fib_params.smac, ETH_ALEN);
                    
                    // bpf_printk("bpf_redirect: %d", bpf_redirect(fib_params.ifindex, 0));
                    return bpf_redirect(fib_params.ifindex, 0);

                }
                else{
                    bpf_printk("rc != BPF_FIB_LKUP_RET_SUCCESS, rc = %d", rc);
                }


            }
            

        }       
        else if (udp->source == bpf_htons(53))
        {

            #ifdef DEBUG
            bpf_printk("------IN RECEIVING-------");
            bpf_printk("recv: Packet src port 53");
            bpf_printk("DNS name: %s", q.name);
            #endif

            //Check if header contains a standard query
            if (dns_hdr->qr == 1)
            {
                
                #ifdef DEBUG
                bpf_printk("DNS resp transaction id %u", bpf_ntohs(dns_hdr->transaction_id));
                bpf_printk("DNS query transaction id %u", bpf_ntohs(dns_hdr->transaction_id));
                #endif


                if (query_length > 256)
                return DEFAULT_ACTION;

                void *resp_start = (void *)query_start + query_length;
                void *cursor = resp_start;

                //Boundary check for minimal DNS rr 
                if (resp_start + sizeof(struct dns_response) > data_end)
                {
                    return DEFAULT_ACTION;
                }
                struct dns_response* rr_start = resp_start;
                #ifdef DEBUG

                bpf_printk("rr name_offset: %d", bpf_ntohs(rr_start->query_pointer) & 0x3FFF);
                bpf_printk("question name offset %d", query_start - (void *)dns_hdr);
                bpf_printk("rr record_type: %d", bpf_ntohs(rr_start->record_type));
                bpf_printk("rr class: %d", bpf_ntohs(rr_start->class));
                bpf_printk("rr ttl: %d", bpf_ntohl(rr_start->ttl));
                bpf_printk("rr data_length: %d", bpf_ntohs(rr_start->data_length));
                
                #endif

                void* rr_data_start = (void *)rr_start + sizeof(struct dns_response);
                int data_len = bpf_ntohs(rr_start->data_length);
                if(data_len > 256){
                    return DEFAULT_ACTION;
                }
                if(rr_data_start + data_len > data_end){
                    return DEFAULT_ACTION;
                }
                cursor = rr_data_start;
        

                uint8_t data[4];
                for(int i=0; i<4; i++, cursor++){
                    if(cursor + 1 > data_end){
                        return DEFAULT_ACTION;
                    }
                    data[i] = *(uint8_t*)(cursor);
                }

                #ifdef DEBUG
                bpf_printk("rr data: %u", data[0]);
                bpf_printk("rr data: %u", data[1]);
                bpf_printk("rr data: %u", data[2]);
                bpf_printk("rr data: %u", data[3]);
                #endif

                struct in_addr* ip_addr;
                if(rr_data_start + sizeof(struct in_addr) > data_end){
                    return DEFAULT_ACTION;
                }
                ip_addr = rr_data_start;

                cursor += 2;
                
                struct a_record a;
                a.ip_addr = *ip_addr;
                a.ttl = bpf_ntohl(rr_start->ttl);
                a.time_inserted_ns = timestamp;

                bpf_map_update_elem(&xdns_a_records, &q, &a, BPF_ANY);

                struct pending_key origin_key;
                origin_key.transaction_id = dns_hdr->transaction_id;

                origin_key.source = udp->dest;

                #ifdef DEBUG
                bpf_printk("origin_key.source: %u", origin_key.source);
                bpf_printk("origin_key.transaction_id: %u", origin_key.transaction_id);
                #endif

                struct pending_request* origin_request = bpf_map_lookup_elem(&xdns_pending_list, &origin_key);
                if(origin_request <= 0){
                    #ifdef DEBUG
                    bpf_printk("empty origin_request!");
                    #endif
                    return DEFAULT_ACTION;
                }

                
                struct bpf_fib_lookup fib_params;
                __builtin_memset(&fib_params, 0, sizeof(fib_params));

                fib_params.family	= AF_INET;
                fib_params.tos		= ip->tos;
                fib_params.l4_protocol	= ip->protocol;
                fib_params.sport	= 0;
                fib_params.dport	= 0;
                fib_params.tot_len	= ntohs(ip->tot_len);
                fib_params.ipv4_src	= ip->daddr;
                fib_params.ipv4_dst	= origin_request->saddr;
                fib_params.ifindex = ctx->ingress_ifindex;

                int delres = bpf_map_delete_elem(&xdns_pending_list, &origin_key);
                #ifdef DEBUG
                if(delres != 0){
                    bpf_printk("failed to delete pending request!");
                }
                else{
                    bpf_printk("deleted pending request! ");
                }
                #endif

                // subtract pending cnt
                int pending_num_key = 0;
                uint32_t* pending_num_value = bpf_map_lookup_elem(&xdns_pending_num, &pending_num_key);
                if (pending_num_value != NULL)
                {
                    #ifdef DEBUG
                    bpf_printk("pending_num_value : %d", *pending_num_value);
                    #endif

                    __sync_fetch_and_add(pending_num_value, -1);
                }

                int rc = bpf_fib_lookup(ctx, &fib_params, sizeof(fib_params), BPF_FIB_LOOKUP_DIRECT);
                if (rc == BPF_FIB_LKUP_RET_SUCCESS) {

                    //Swap src/dst IP
                    ip->saddr = ip->daddr;
                    ip->daddr = origin_request->saddr;
    
                    //Recalculate IP checksum
                    update_ip_checksum(ip, sizeof(struct iphdr), &ip->check);
                    udp->check = 0;
                    memcpy(eth->h_dest, fib_params.dmac, ETH_ALEN);
                    memcpy(eth->h_source, fib_params.smac, ETH_ALEN);
                    
                    // bpf_printk("bpf_redirect: %d", bpf_redirect(fib_params.ifindex, 0));
                    return bpf_redirect(fib_params.ifindex, 0);

                }
                else{
                    bpf_printk("rc != BPF_FIB_LKUP_RET_SUCCESS, rc = %d", rc);
                }
                
            
            }

        }
    }

    return DEFAULT_ACTION;
}

static int match_a_records(struct xdp_md *ctx, struct dns_query *q, struct a_record *a)
{
    #ifdef DEBUG
    bpf_printk("DNS record type: %i", q->record_type);
    bpf_printk("DNS class: %i", q->class);
    bpf_printk("DNS name: %s", q->name);
    #endif

    struct a_record *record;
    // #ifdef BCC_SEC
    // record = xdns_a_records.lookup(q);
    // #else
    record = bpf_map_lookup_elem(&xdns_a_records, q);
    // #endif

    //If record pointer is not zero..
    if (record > 0)
    {
        #ifdef DEBUG
        bpf_printk("DNS query matched");
        #endif
        a->ip_addr = record->ip_addr;
        a->ttl = record->ttl;
        a->time_inserted_ns = record->time_inserted_ns;
        return 0;
    }

    return -1;
}

//Parse query and return query length
static int parse_query(struct xdp_md *ctx, void *query_start, struct dns_query *q)
{
    void *data_end = (void *)(long)ctx->data_end;

    #ifdef DEBUG
    bpf_printk("Parsing query");
    #endif

    uint16_t i;
    void *cursor = query_start;
    int namepos = 0;

    //Fill dns_query.name with zero bytes
    //Not doing so will make the verifier complain when dns_query is used as a key in bpf_map_lookup
    memset(&q->name[0], 0, sizeof(q->name));
    //Fill record_type and class with default values to satisfy verifier
    q->record_type = 0;
    q->class = 0;

    //We create a bounded loop of MAX_DNS_NAME_LENGTH (maximum allowed dns name size).
    //We'll loop through the packet byte by byte until we reach '0' in order to get the dns query name
    for (i = 0; i < MAX_DNS_NAME_LENGTH; i++)
    {

        //Boundary check of cursor. Verifier requires a +1 here. 
        //Probably because we are advancing the pointer at the end of the loop
        if (cursor + 1 > data_end)
        {
            #ifdef DEBUG
            bpf_printk("Error: boundary exceeded while parsing DNS query name");
            #endif
            break;
        }

        /*
        #ifdef DEBUG
        bpf_printk("Cursor contents is %u\n", *(char *)cursor);
        #endif
        */

        //If separator is zero we've reached the end of the domain query
        if (*(char *)(cursor) == 0)
        {

            //We've reached the end of the query name.
            //This will be followed by 2x 2 bytes: the dns type and dns class.
            if (cursor + 5 > data_end)
            {
                #ifdef DEBUG
                bpf_printk("Error: boundary exceeded while retrieving DNS record type and class");
                #endif
            }
            else
            {
                q->record_type = bpf_htons(*(uint16_t *)(cursor + 1));
                q->class = bpf_htons(*(uint16_t *)(cursor + 3));
            }

            //Return the bytecount of (namepos + current '0' byte + dns type + dns class) as the query length.
            return namepos + 1 + 2 + 2;
        }

        //Read and fill data into struct
        q->name[namepos] = *(char *)(cursor);
        namepos++;
        cursor++;
    }

    return -1;
}


#ifdef EDNS
//Parse additonal record
static inline int parse_ar(struct xdp_md *ctx, struct dns_hdr *dns_hdr, int query_length, struct ar_hdr *ar)
{
    #ifdef DEBUG
    bpf_printk("Parsing additional record in query");
    #endif

    void *data_end = (void *)(long)ctx->data_end;

    //Parse ar record
    ar  = (void *) dns_hdr + query_length + sizeof(struct dns_response);
    if((void*) ar + sizeof(struct ar_hdr) > data_end){
        #ifdef DEBUG
        bpf_printk("Error: boundary exceeded while parsing additional record");
        #endif
        return -1;
    }

    return 0;
}

static inline int create_ar_response(struct ar_hdr *ar, char *dns_buffer, size_t *buf_size)
{
    //Check for OPT record (RFC6891)
    if(ar->type == bpf_htons(41)){
        #ifdef DEBUG
        bpf_printk("OPT record found");
        #endif
        struct ar_hdr *ar_response = (struct ar_hdr *) &dns_buffer[0];
        //We've received an OPT record, advertising the clients' UDP payload size
        //Respond that we're serving a payload size of 512 and not serving any additional records.
        ar_response->name = 0;
        ar_response->type = bpf_htons(41);
        ar_response->size = bpf_htons(512);
        ar_response->ex_rcode = 0;
        ar_response->rcode_len = 0;

        *buf_size += sizeof(struct ar_hdr);
    }
    else
    {
        return -1;
    }
        
    return 0;
}
#endif

static void create_query_response(struct a_record *a, char *dns_buffer, size_t *buf_size)
{
    //Formulate a DNS response. Currently defaults to hardcoded query pointer + type a + class in + ttl + 4 bytes as reply.
    struct dns_response *response = (struct dns_response *) &dns_buffer[0];
    response->query_pointer = bpf_htons(0xc00c);
    response->record_type = bpf_htons(0x0001);
    response->class = bpf_htons(0x0001);
    response->ttl = bpf_htonl(a->ttl);
    response->data_length = bpf_htons((uint16_t)sizeof(a->ip_addr));
    *buf_size += sizeof(struct dns_response);
    //Copy IP address
    __builtin_memcpy(&dns_buffer[*buf_size], &a->ip_addr, sizeof(struct in_addr));
    *buf_size += sizeof(struct in_addr);
}

//Update IP checksum for IP header, as specified in RFC 1071
//The checksum_location is passed as a pointer. At this location 16 bits need to be set to 0.
static inline void update_ip_checksum(void *data, int len, uint16_t *checksum_location)
{
    uint32_t accumulator = 0;
    int i;
    for (i = 0; i < len; i += 2)
    {
        uint16_t val;
        //If we are currently at the checksum_location, set to zero
        if (data + i == checksum_location)
        {
            val = 0;
        }
        else
        {
            //Else we load two bytes of data into val
            val = *(uint16_t *)(data + i);
        }
        accumulator += val;
    }

    //Add 16 bits overflow back to accumulator (if necessary)
    uint16_t overflow = accumulator >> 16;
    accumulator &= 0x00FFFF;
    accumulator += overflow;

    //If this resulted in an overflow again, do the same (if necessary)
    accumulator += (accumulator >> 16);
    accumulator &= 0x00FFFF;

    //Invert bits and set the checksum at checksum_location
    uint16_t chk = accumulator ^ 0xFFFF;

    #ifdef DEBUG
    bpf_printk("Checksum: %u", chk);
    #endif

    *checksum_location = chk;
}

static inline void modify_dns_header_response(struct dns_hdr *dns_hdr)
{
    //Set query response
    dns_hdr->qr = 1;
    //Set truncated to 0
    //dns_hdr->tc = 0;
    //Set authorative to zero
    //dns_hdr->aa = 0;
    //Recursion available
    dns_hdr->ra = 1;
    //One answer
    dns_hdr->ans_count = bpf_htons(1);
}

//__builtin_memcpy only supports static size_t
//The following function is a memcpy wrapper that uses __builtin_memcpy when size_t n is known.
//Otherwise it uses our own naive & slow memcpy routine
static inline void copy_to_pkt_buf(struct xdp_md *ctx, void *dst, void *src, size_t n)
{
    //Boundary check
    if((void *)(long)ctx->data_end >= dst + n){
        int i;
        char *cdst = dst;
        char *csrc = src;

        //For A records, src is either 16 or 27 bytes, depending if OPT record is requested.
        //Use __builtin_memcpy for this. Otherwise, use our own slow, naive memcpy implementation.
        switch(n)
        {
            case 16:
                __builtin_memcpy(cdst, csrc, 16);
                break;
            
            case 27:
                __builtin_memcpy(cdst, csrc, 27);
                break;

            default:
                for(i = 0; i < n; i+=1)
                {
                    cdst[i] = csrc[i];
                }
        }
    }
}

static inline void swap_mac(uint8_t *src_mac, uint8_t *dst_mac)
{
    int i;
    for (i = 0; i < 6; i++)
    {
        uint8_t tmp_src;
        tmp_src = *(src_mac + i);
        *(src_mac + i) = *(dst_mac + i);
        *(dst_mac + i) = tmp_src;
    }
}

#ifndef BCC_SEC
char _license[] SEC("license") = "GPL";
__u32 _version SEC("version") = LINUX_VERSION_CODE;
#endif
