#define DEFAULT_ACTION XDP_PASS

#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/version.h>

//This program supports XDP in BCC and libbpf+iproute2 mode
//Include different files depending on mode
#ifndef BCC_SEC
#include <netinet/in.h>
#include <bpf_helpers.h>
#include <bpf_endian.h>
#include <string.h>
#include <stdint.h>
//bpf_elf.h is part of iproute2
#include <bpf_elf.h>
#endif

#include "common.h"

/* Special map type that can XDP_REDIRECT frames to another CPU */
struct bpf_elf_map SEC("maps") cpu_map = {
    .type = BPF_MAP_TYPE_CPUMAP,
    .size_key = sizeof(uint32_t),
    .size_value = sizeof(struct bpf_cpumap_val),
    .max_elem = CPU_CORES,
};

struct bpf_elf_map SEC("maps") dis_ts = {
    .type = BPF_MAP_TYPE_HASH,
    .size_key = sizeof(struct pending_key),
    .size_value = sizeof(struct timestamp),
    .max_elem = 65536,
};


#define FNV_PRIME 16777619
#define FNV_OFFSET_BASIS 2166136261U

static int parse_query(struct xdp_md *ctx, void *query_start, struct dns_query *q);

static __always_inline unsigned int fnv1a_hash(const char* data, int len);

char dns_buffer[512];

#ifndef BCC_SEC
SEC("xdp_prog")
#endif
int xdp_dns(struct xdp_md *ctx)
{

    uint64_t time_in = bpf_ktime_get_ns();

    #ifdef BCC_SEC
    char dns_buffer[512];
    #endif

    void *data_end = (void *)(unsigned long)ctx->data_end;
    void *data = (void *)(unsigned long)ctx->data;

    //Boundary check: check if packet is larger than a full ethernet + ip header
    if (data + sizeof(struct ethhdr) + sizeof(struct iphdr) > data_end)
    {
        return DEFAULT_ACTION;
    }

    struct ethhdr *eth = data;

    //Ignore packet if ethernet protocol is not IP-based
    if (eth->h_proto != bpf_htons(ETH_P_IP))
    {
        return DEFAULT_ACTION;
    }

    struct iphdr *ip = data + sizeof(*eth);

    if (ip->protocol == IPPROTO_UDP)
    {
        struct udphdr *udp;
        //Boundary check for UDP
        if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp) > data_end)
        {
            return DEFAULT_ACTION;
        }
        
        udp = data + sizeof(*eth) + sizeof(*ip);
        // not a DNS packet
        if (udp->dest != bpf_htons(53) && udp->source != bpf_htons(53)){
            return DEFAULT_ACTION;
        }

        uint64_t timestamp = bpf_ktime_get_ns() / 1000000000;
        //Boundary check for minimal DNS header
        if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp) + sizeof(struct dns_hdr) > data_end)
        {
            return DEFAULT_ACTION;
        }
        struct dns_hdr *dns_hdr = data + sizeof(*eth) + sizeof(*ip) + sizeof(*udp);

        //Get a pointer to the start of the DNS query
        void *query_start = (void *)dns_hdr + sizeof(struct dns_hdr);

        struct dns_query q;
        int query_length = 0;
        query_length = parse_query(ctx, query_start, &q);
        if (query_length < 1)
        {
            return DEFAULT_ACTION;
        }

        int len = 0;
        while (len < 10 && q.name[len] != '\0') {
            len++;
        }
        int hash = fnv1a_hash(q.name, len);
        unsigned int curr_cpu = bpf_get_smp_processor_id();
        #ifdef DEBUG
        do{
            char fmt[] = "======Inside Dispatcher======";
            bpf_trace_printk(fmt, sizeof(fmt), CPU_CORES, dns_hdr->transaction_id);
        }while(0);

        do{
            char fmt[] = "Request domain name: %s\n";
            bpf_trace_printk(fmt, sizeof(fmt), q.name);
        }while(0);

        do{
            char fmt[] = "Number of CPU cores: %d, transaction id: %d\n";
            bpf_trace_printk(fmt, sizeof(fmt), CPU_CORES, dns_hdr->transaction_id);
        }while(0);
        
        do{
            char fmt[] = "bpf_get_smp_processor_id: %u\n";
            bpf_trace_printk(fmt, sizeof(fmt), curr_cpu);
        }while(0);

        do{
            char fmt[] = "fnv1a_hash: %d\n";
            bpf_trace_printk(fmt, sizeof(fmt), hash);
        }while(0);
        
        do{
            char fmt[] = "sending to cpu: %d";
            bpf_trace_printk(fmt, sizeof(fmt), hash, dns_hdr->transaction_id);
        }while(0);
        #endif

        uint64_t time_out = bpf_ktime_get_ns();
        struct pending_key dis_key = {};
        dis_key.transaction_id = dns_hdr -> transaction_id;
        dis_key.source = udp -> source;
        struct timestamp dis_time_val = {};
        dis_time_val.time_in = time_in;
        dis_time_val.time_out = time_out;

        bpf_map_update_elem(&dis_ts, &dis_key, &dis_time_val, BPF_ANY);

        return bpf_redirect_map(&cpu_map, hash, 0);
        
        

    }

    return DEFAULT_ACTION;
}




//Parse query and return query length
static int parse_query(struct xdp_md *ctx, void *query_start, struct dns_query *q)
{
    void *data_end = (void *)(long)ctx->data_end;

    uint16_t i;
    void *cursor = query_start;
    int namepos = 0;

    //Fill dns_query.name with zero bytes
    //Not doing so will make the verifier complain when dns_query is used as a key in bpf_map_lookup
    memset(&q->name[0], 0, sizeof(q->name));
    //Fill record_type and class with default values to satisfy verifier
    q->record_type = 0;
    q->class = 0;

    //We create a bounded loop of MAX_DNS_NAME_LENGTH (maximum allowed dns name size).
    //We'll loop through the packet byte by byte until we reach '0' in order to get the dns query name
    for (i = 0; i < MAX_DNS_NAME_LENGTH; i++)
    {

        //Boundary check of cursor. Verifier requires a +1 here. 
        //Probably because we are advancing the pointer at the end of the loop
        if (cursor + 1 > data_end)
        {
            break;
        }

        //If separator is zero we've reached the end of the domain query
        if (*(char *)(cursor) == 0)
        {

            //We've reached the end of the query name.
            //This will be followed by 2x 2 bytes: the dns type and dns class.
            if (cursor + 5 <= data_end)
            {
                q->record_type = bpf_htons(*(uint16_t *)(cursor + 1));
                q->class = bpf_htons(*(uint16_t *)(cursor + 3));
            }

            //Return the bytecount of (namepos + current '0' byte + dns type + dns class) as the query length.
            return namepos + 1 + 2 + 2;
        }

        //Read and fill data into struct
        q->name[namepos] = *(char *)(cursor);
        namepos++;
        cursor++;
    }

    return -1;
}




static __always_inline unsigned int fnv1a_hash(const char* data, int len) {
  unsigned int hash = FNV_OFFSET_BASIS;
  int i;
  for (i = 0; i < len && data[i] != '\0'; i++) {
    hash ^= (unsigned int)data[i];
    hash *= FNV_PRIME;
  }
  return hash % CPU_CORES;
}

#ifndef BCC_SEC
char _license[] SEC("license") = "GPL";
__u32 _version SEC("version") = LINUX_VERSION_CODE;
#endif
